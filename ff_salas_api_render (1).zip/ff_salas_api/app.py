"""
FF Salas API — API livre, sem autenticação.
Comunicação direta com servidores Garena via protobuf criptografado (AES-CBC).
"""
import os
import threading
import time
from datetime import datetime, timezone
from flask import Flask, request, jsonify
from flask_cors import CORS

import session_store as store
from ff_client import FFRoomClient, CONFIG_TEMPLATES
from freefire_guest_generator import create_single_account

app = Flask(__name__)
CORS(app)


class _PrefixMiddleware:
    def __init__(self, wsgi_app, prefix):
        self.wsgi_app = wsgi_app
        self.prefix = prefix

    def __call__(self, environ, start_response):
        path = environ.get("PATH_INFO", "/")
        if path.startswith(self.prefix):
            environ["PATH_INFO"] = path[len(self.prefix):] or "/"
            environ["SCRIPT_NAME"] = self.prefix
        return self.wsgi_app(environ, start_response)


_prefix = os.environ.get("APP_PREFIX", "")
if _prefix:
    app.wsgi_app = _PrefixMiddleware(app.wsgi_app, _prefix)

store.init_db()


def _purge_loop():
    while True:
        try:
            store.purge_expired()
        except Exception:
            pass
        time.sleep(30)

threading.Thread(target=_purge_loop, daemon=True).start()


def _session_response(session: dict) -> dict:
    return {
        "session_id": session["session_id"],
        "room_id": session["room_id"],
        "room_name": session["room_name"],
        "password": session["password"],
        "account_uid": session["account_uid"],
        "region": session["region"],
        "status": session["status"],
        "config_type": session["config_type"],
        "invite_code": session["invite_code"],
        "invite_link": session["invite_link"],
        "invite_code_candidates": session.get("invite_code_candidates", []),
        "expires_at": session["expires_at"],
        "created_at": session["created_at"],
    }


def _get_active_session(session_id: str):
    session = store.get_session(session_id)
    if not session:
        return None, jsonify({"detail": "Sessão não encontrada"}), 404
    if session["status"] == "released":
        return None, jsonify({"detail": "Sessão encerrada"}), 404
    return session, None, None


@app.get("/health")
def health():
    return jsonify({"status": "ok", "version": "1.0.0"})


@app.post("/rooms")
def create_room():
    body = request.get_json(silent=True) or {}

    password = body.get("password")
    delay = body.get("start_delay_minutes")
    config_type = body.get("config_type", "ap_padrao")
    room_name = body.get("room_name", "Sala FF")
    region = body.get("region", "BR").upper()

    if not password:
        return jsonify({"detail": "Campo 'password' é obrigatório"}), 422
    if not isinstance(password, str) or not (1 <= len(password) <= 16):
        return jsonify({"detail": "password deve ter entre 1 e 16 caracteres"}), 422
    if delay is None:
        return jsonify({"detail": "Campo 'start_delay_minutes' é obrigatório"}), 422
    if not isinstance(delay, int) or not (3 <= delay <= 10):
        return jsonify({"detail": "start_delay_minutes deve ser entre 3 e 10"}), 422
    if config_type not in CONFIG_TEMPLATES:
        return jsonify({
            "detail": f"config_type inválido. Opções: {list(CONFIG_TEMPLATES.keys())}"
        }), 422

    try:
        account = create_single_account(region, "Host")
        jwt_token = account["jwt_token"]
        account_uid = account["uid"]

        client = FFRoomClient(jwt_token=jwt_token, region=region)
        room_data = client.create_room(
            password=password,
            room_name=room_name,
            config_type=config_type,
        )

        room_id = room_data["room_id"]
        if not room_id:
            return jsonify({"detail": "Falha ao criar sala no servidor FF"}), 503

        session = store.create_session(
            room_id=room_id,
            room_name=room_name,
            password=password,
            account_uid=account_uid,
            account_jwt=jwt_token,
            region=region,
            config_type=config_type,
            invite_code=room_data["invite_code"],
            invite_link=room_data["invite_link"],
            invite_codes=room_data["invite_code_candidates"],
            delay_minutes=delay,
            user_token="free",
        )

        return jsonify(_session_response(session)), 201

    except Exception as e:
        app.logger.error(f"Erro ao criar sala: {e}", exc_info=True)
        return jsonify({"detail": f"Falha operacional: {str(e)}"}), 503


@app.get("/rooms/<session_id>")
def get_room(session_id):
    session, err, code = _get_active_session(session_id)
    if err:
        return err, code

    if session["status"] == "active":
        try:
            client = FFRoomClient(
                jwt_token=session["account_jwt"],
                region=session["region"],
            )
            members = client.get_members(session["room_id"])
            for m in members:
                store.upsert_member(session_id, m)
        except Exception:
            pass

    return jsonify(_session_response(session))


@app.get("/rooms/<session_id>/members")
def get_members(session_id):
    session, err, code = _get_active_session(session_id)
    if err:
        return err, code

    if session["status"] not in ("active", "started"):
        return jsonify({"detail": "Sessão não está ativa"}), 409

    try:
        client = FFRoomClient(
            jwt_token=session["account_jwt"],
            region=session["region"],
        )
        live_members = client.get_members(session["room_id"])
        for m in live_members:
            store.upsert_member(session_id, m)
    except Exception:
        pass

    members = store.get_members(session_id)
    return jsonify({
        "session_id": session_id,
        "room_id": session["room_id"],
        "status": session["status"],
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "member_count": len(members),
        "members": members,
    })


@app.post("/rooms/<session_id>/kick")
def kick_player(session_id):
    session, err, code = _get_active_session(session_id)
    if err:
        return err, code

    if session["status"] != "active":
        return jsonify({"detail": "Ação inválida: sala não está ativa"}), 409

    body = request.get_json(silent=True) or {}
    player_uid = body.get("player_uid")
    if not player_uid:
        return jsonify({"detail": "Campo 'player_uid' é obrigatório"}), 422

    if str(player_uid) == str(session["account_uid"]):
        return jsonify({"detail": "Não é permitido expulsar o dono da sala"}), 422

    try:
        client = FFRoomClient(
            jwt_token=session["account_jwt"],
            region=session["region"],
        )
        success = client.kick_player(session["room_id"], str(player_uid))
        if success:
            with store._conn() as con:
                con.execute(
                    "DELETE FROM session_members WHERE session_id=? AND player_uid=?",
                    (session_id, str(player_uid)),
                )
            return jsonify({"detail": "Jogador expulso com sucesso"})
        return jsonify({"detail": "Falha ao expulsar jogador"}), 503
    except Exception as e:
        return jsonify({"detail": f"Falha operacional: {str(e)}"}), 503


@app.post("/rooms/<session_id>/start")
def start_room(session_id):
    session, err, code = _get_active_session(session_id)
    if err:
        return err, code

    if session["status"] != "active":
        return jsonify({"detail": "Ação inválida: sala não está ativa"}), 409

    try:
        client = FFRoomClient(
            jwt_token=session["account_jwt"],
            region=session["region"],
        )
        success = client.start_room(session["room_id"])
        if success:
            store.update_status(session_id, "started")
            return jsonify({"detail": "Partida iniciada", "session_id": session_id})
        return jsonify({"detail": "Falha ao iniciar partida"}), 503
    except Exception as e:
        return jsonify({"detail": f"Falha operacional: {str(e)}"}), 503


@app.post("/rooms/<session_id>/release")
def release_room(session_id):
    session = store.get_session(session_id)
    if not session:
        return jsonify({"detail": "Sessão não encontrada"}), 404

    try:
        client = FFRoomClient(
            jwt_token=session["account_jwt"],
            region=session["region"],
        )
        client.leave_room(session["room_id"])
    except Exception:
        pass

    store.delete_session(session_id)
    return jsonify({"detail": "Sessão encerrada com sucesso"})


@app.get("/stats/tc")
def stats_tc():
    ids_param = request.args.get("ids", "")
    if not ids_param:
        return jsonify({"detail": "Parâmetro 'ids' é obrigatório"}), 422

    raw_ids = [i.strip() for i in ids_param.split(",") if i.strip()]
    if not raw_ids:
        return jsonify({"detail": "Nenhum ID válido fornecido"}), 422
    if len(raw_ids) > 50:
        return jsonify({"detail": "Máximo de 50 IDs por requisição"}), 422

    results = _fetch_stats_tc(raw_ids)
    return jsonify({"results": results})


def _fetch_stats_tc(account_ids: list[str]) -> list[dict]:
    import requests as rq

    results = []
    try:
        acc = create_single_account("BR", "StatsBot")
        jwt = acc["jwt_token"]

        for aid in account_ids:
            try:
                from ff_client import (
                    _field_varint,
                    aes_encrypt, aes_decrypt, decode_proto, _ff_headers
                )
                proto = _field_varint(1, int(aid))
                encrypted = aes_encrypt(proto)

                resp = rq.post(
                    "https://clientbp.ggblueshark.com/GetPlayerTCStats",
                    data=encrypted,
                    headers=_ff_headers(jwt, "BR"),
                    verify=False,
                    timeout=10,
                )
                if resp.ok and resp.content:
                    raw = aes_decrypt(resp.content)
                    fields = decode_proto(raw)
                    results.append({
                        "account_id": int(aid),
                        "matches": fields.get(1, 0),
                        "wins": fields.get(2, 0),
                        "kills": fields.get(3, 0),
                        "mvp": fields.get(4, 0),
                    })
                else:
                    results.append({"account_id": int(aid), "error": "not_found"})
            except Exception:
                results.append({"account_id": int(aid), "error": "fetch_failed"})
    except Exception as e:
        return [{"error": str(e)}]

    return results


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    debug = os.environ.get("DEBUG", "false").lower() == "true"
    app.run(host="0.0.0.0", port=port, debug=debug)
