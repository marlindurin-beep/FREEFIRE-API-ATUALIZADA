"""
Free Fire Guest Account Generator

A library to generate Free Fire guest accounts with full details.
"""

from .generator import generate_accounts, create_single_account

__all__ = ["generate_accounts", "create_single_account"]