# salas-ff-api

API REST para criação e gerenciamento de salas personalizadas no Free Fire.
Comunicação direta com os servidores da Garena via protobuf criptografado (AES-CBC).

## Instalação

```bash
pip install salas-ff-api
```

## Uso

```bash
salas-ff-api
```

Ou com porta personalizada:

```bash
PORT=8080 salas-ff-api
```

A API sobe em `http://localhost:8000` por padrão.

## Endpoints

| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/health` | Status da API |
| POST | `/rooms` | Cria sala personalizada |
| GET | `/rooms/{id}` | Consulta sala |
| GET | `/rooms/{id}/members` | Lista jogadores |
| POST | `/rooms/{id}/kick` | Expulsa jogador |
| POST | `/rooms/{id}/start` | Inicia partida |
| POST | `/rooms/{id}/release` | Encerra sala |
| GET | `/stats/tc?ids=...` | Estatísticas TC |

## Exemplo

```bash
curl -X POST http://localhost:8000/rooms \
  -H "Content-Type: application/json" \
  -d '{"password": "123456", "start_delay_minutes": 5, "region": "BR"}'
```

## Configuração

| Variável | Padrão | Descrição |
|----------|--------|-----------|
| PORT | 8000 | Porta da API |
| DEBUG | false | Modo debug |
