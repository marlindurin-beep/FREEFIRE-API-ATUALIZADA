"""
FF Game Server Client — comunica diretamente com os servidores da Garena
via protobuf criptografado com AES-CBC.
"""
import base64
import struct
import time
import uuid
import json
import requests
import urllib3
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Chaves AES do protocolo Free Fire
AES_KEY = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
AES_IV  = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])

# Servidores por região
REGION_SERVERS = {
    "BR":  ("https://clientbp.ggblueshark.com", "https://loginbp.ggblueshark.com"),
    "IND": ("https://clientbp.ggblueshark.com", "https://loginbp.ggblueshark.com"),
    "ID":  ("https://clientbp.ggblueshark.com", "https://loginbp.ggblueshark.com"),
    "ME":  ("https://clientbp.common.ggbluefox.com", "https://loginbp.common.ggbluefox.com"),
    "TH":  ("https://clientbp.common.ggbluefox.com", "https://loginbp.common.ggbluefox.com"),
    "VN":  ("https://clientbp.ggblueshark.com", "https://loginbp.ggblueshark.com"),
    "CIS": ("https://clientbp.ggblueshark.com", "https://loginbp.ggblueshark.com"),
    "SAC": ("https://clientbp.ggblueshark.com", "https://loginbp.ggblueshark.com"),
    "BD":  ("https://clientbp.ggblueshark.com", "https://loginbp.ggblueshark.com"),
    "PK":  ("https://clientbp.ggblueshark.com", "https://loginbp.ggblueshark.com"),
    "TW":  ("https://clientbp.ggblueshark.com", "https://loginbp.ggblueshark.com"),
}

# Configurações de mapa por tipo
CONFIG_TEMPLATES = {
    "ap_padrao": {
        "game_mode": 0,
        "map_id": 1,
        "max_players": 12,
        "time_limit": 180,
    },
    "gelo_inf": {
        "game_mode": 0,
        "map_id": 7,
        "max_players": 12,
        "time_limit": 180,
    },
    "tatico": {
        "game_mode": 5,
        "map_id": 1,
        "max_players": 8,
        "time_limit": 120,
    },
    "ap_fullcapa": {
        "game_mode": 0,
        "map_id": 1,
        "max_players": 12,
        "time_limit": 180,
    },
    "capa_3": {
        "game_mode": 0,
        "map_id": 1,
        "max_players": 6,
        "time_limit": 120,
    },
    "ap_uxd": {
        "game_mode": 0,
        "map_id": 1,
        "max_players": 12,
        "time_limit": 180,
    },
}


# ─── Protobuf helpers ─────────────────────────────────────────────────────────

def _encode_varint(value: int) -> bytes:
    pieces = []
    while value > 0x7F:
        pieces.append((value & 0x7F) | 0x80)
        value >>= 7
    pieces.append(value)
    return bytes(pieces)


def _field_varint(field_number: int, value: int) -> bytes:
    tag = (field_number << 3) | 0
    return _encode_varint(tag) + _encode_varint(value)


def _field_string(field_number: int, value: str | bytes) -> bytes:
    tag = (field_number << 3) | 2
    encoded = value.encode() if isinstance(value, str) else value
    return _encode_varint(tag) + _encode_varint(len(encoded)) + encoded


def _field_message(field_number: int, payload: bytes) -> bytes:
    tag = (field_number << 3) | 2
    return _encode_varint(tag) + _encode_varint(len(payload)) + payload


def _read_varint(data: bytes, pos: int) -> tuple[int, int]:
    result = 0
    shift = 0
    while pos < len(data):
        b = data[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if not (b & 0x80):
            break
        shift += 7
    return result, pos


def decode_proto(data: bytes) -> dict:
    """Decodifica campos protobuf básicos (varint, string/bytes).
    Campos repetidos são acumulados em lista.
    """
    fields = {}
    pos = 0
    while pos < len(data):
        tag, pos = _read_varint(data, pos)
        field_number = tag >> 3
        wire_type = tag & 0x7
        if wire_type == 0:
            value, pos = _read_varint(data, pos)
        elif wire_type == 2:
            length, pos = _read_varint(data, pos)
            raw = data[pos:pos + length]
            pos += length
            try:
                value = raw.decode("utf-8")
            except Exception:
                value = raw
        elif wire_type == 5:
            value = data[pos:pos + 4]
            pos += 4
        elif wire_type == 1:
            value = data[pos:pos + 8]
            pos += 8
        else:
            break
        if field_number in fields:
            existing = fields[field_number]
            if isinstance(existing, list):
                existing.append(value)
            else:
                fields[field_number] = [existing, value]
        else:
            fields[field_number] = value
    return fields


# ─── AES helpers ──────────────────────────────────────────────────────────────

def aes_encrypt(data: bytes) -> bytes:
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    return cipher.encrypt(pad(data, AES.block_size))


def aes_decrypt(data: bytes) -> bytes:
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    return unpad(cipher.decrypt(data), AES.block_size)


# ─── HTTP helpers ─────────────────────────────────────────────────────────────

def _ff_headers(jwt_token: str, region: str = "BR") -> dict:
    return {
        "Authorization": f"Bearer {jwt_token}",
        "Content-Type": "application/octet-stream",
        "User-Agent": (
            "Dalvik/2.1.0 (Linux; U; Android 9; "
            "ASUS_Z01QD Build/PKQ1.190101.001)"
        ),
        "ReleaseVersion": "OB52",
        "X-Unity-Version": "2018.4.11f1",
        "Region": region.upper(),
    }


def _post_ff(client_url: str, path: str, proto: bytes, jwt_token: str, region: str) -> bytes:
    encrypted = aes_encrypt(proto)
    resp = requests.post(
        f"{client_url}{path}",
        data=encrypted,
        headers=_ff_headers(jwt_token, region),
        verify=False,
        timeout=20,
    )
    resp.raise_for_status()
    if resp.content:
        return aes_decrypt(resp.content)
    return b""


# ─── Room operations ──────────────────────────────────────────────────────────

class FFRoomClient:
    def __init__(self, jwt_token: str, region: str = "BR"):
        self.jwt_token = jwt_token
        self.region = region.upper()
        self.client_url, self.login_url = REGION_SERVERS.get(
            self.region, REGION_SERVERS["BR"]
        )

    def create_room(
        self,
        password: str,
        room_name: str = "Sala",
        config_type: str = "ap_padrao",
    ) -> dict:
        """
        Cria uma sala personalizada no Free Fire.
        Retorna dict com room_id, invite_code, invite_link.
        """
        cfg = CONFIG_TEMPLATES.get(config_type, CONFIG_TEMPLATES["ap_padrao"])

        proto = (
            _field_string(1, password)        # senha da sala
            + _field_string(2, room_name)     # nome
            + _field_varint(3, cfg["game_mode"])   # modo
            + _field_varint(4, cfg["map_id"])      # mapa
            + _field_varint(5, cfg["max_players"]) # max jogadores
            + _field_varint(6, cfg["time_limit"])  # tempo em segundos
        )

        raw = _post_ff(self.client_url, "/CreateCustomRoom", proto, self.jwt_token, self.region)
        fields = decode_proto(raw)

        room_id = fields.get(1, 0)
        invite_code = fields.get(2, "") or fields.get(3, "")
        invite_link = fields.get(5, "") or (
            f"https://ffshare.garena.com/share?roomId={room_id}&code={invite_code}"
            if room_id else ""
        )

        return {
            "room_id": room_id,
            "invite_code": str(invite_code),
            "invite_link": str(invite_link),
            "invite_code_candidates": [str(invite_code)] if invite_code else [],
            "raw_fields": fields,
        }

    def get_room_info(self, room_id: int) -> dict:
        """Consulta informações e status da sala."""
        proto = _field_varint(1, room_id)
        raw = _post_ff(self.client_url, "/GetCustomRoomInfo", proto, self.jwt_token, self.region)
        return decode_proto(raw)

    def get_members(self, room_id: int) -> list[dict]:
        """Lista os membros atuais da sala."""
        proto = _field_varint(1, room_id)
        raw = _post_ff(self.client_url, "/GetRoomMembers", proto, self.jwt_token, self.region)
        fields = decode_proto(raw)

        members = []
        # Campo 2 é lista de membros (repeated message)
        raw_members = fields.get(2, b"")
        if isinstance(raw_members, bytes):
            member_fields = decode_proto(raw_members)
            if member_fields:
                members.append(_parse_member(member_fields))
        return members

    def kick_player(self, room_id: int, player_uid: str) -> bool:
        """Expulsa um jogador da sala."""
        proto = (
            _field_varint(1, room_id)
            + _field_string(2, player_uid)
        )
        raw = _post_ff(self.client_url, "/KickPlayer", proto, self.jwt_token, self.region)
        fields = decode_proto(raw)
        return fields.get(1, 0) == 1

    def start_room(self, room_id: int) -> bool:
        """Envia o comando de start da sala."""
        proto = _field_varint(1, room_id)
        raw = _post_ff(self.client_url, "/StartCustomRoom", proto, self.jwt_token, self.region)
        fields = decode_proto(raw)
        return fields.get(1, 0) == 1

    def leave_room(self, room_id: int) -> bool:
        """Sai/encerra a sala."""
        proto = _field_varint(1, room_id)
        _post_ff(self.client_url, "/LeaveCustomRoom", proto, self.jwt_token, self.region)
        return True


def _parse_member(fields: dict) -> dict:
    return {
        "player_uid": str(fields.get(1, "")),
        "nickname": str(fields.get(2, "")),
        "is_owner": bool(fields.get(3, 0)),
        "team": int(fields.get(4, 1)),
        "slot": int(fields.get(5, 1)),
        "platform": "mobile" if fields.get(6, 0) == 0 else "emulator",
        "joined_at": None,
        "updated_at": None,
        "last_event": "",
    }
