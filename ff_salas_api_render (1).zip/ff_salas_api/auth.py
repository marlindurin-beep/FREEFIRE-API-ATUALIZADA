"""
Middleware de autenticação via Bearer token.
"""
from functools import wraps
from flask import request, jsonify
import session_store as store


def require_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"detail": "Token ausente ou inválido"}), 401
        token = auth[7:].strip()
        user = store.get_user(token)
        if not user:
            return jsonify({"detail": "Token não encontrado"}), 401
        if not user.get("enabled", 1):
            return jsonify({"detail": "Token desabilitado"}), 403
        request.user = user
        request.user_token = token
        return f(*args, **kwargs)
    return decorated
