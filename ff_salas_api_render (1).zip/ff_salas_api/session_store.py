"""
Gerenciamento de sessões em SQLite.
Cada sessão representa uma sala FF ativa com seu bot owner.
"""
import sqlite3
import uuid
import json
from datetime import datetime, timezone, timedelta
from contextlib import contextmanager

import os as _os
DB_PATH = _os.environ.get("DB_PATH", _os.path.join(_os.path.dirname(__file__), "sessions.db"))


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _expires_at(minutes: int) -> str:
    return (datetime.now(timezone.utc) + timedelta(minutes=minutes)).isoformat()


@contextmanager
def _conn():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    try:
        yield con
        con.commit()
    finally:
        con.close()


def init_db():
    with _conn() as con:
        con.executescript("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id   TEXT PRIMARY KEY,
                room_id      INTEGER,
                room_name    TEXT,
                password     TEXT,
                account_uid  TEXT,
                account_jwt  TEXT,
                region       TEXT,
                status       TEXT DEFAULT 'active',
                config_type  TEXT,
                invite_code  TEXT,
                invite_link  TEXT,
                invite_codes TEXT,
                created_at   TEXT,
                expires_at   TEXT,
                started_at   TEXT,
                released_at  TEXT,
                user_token   TEXT
            );

            CREATE TABLE IF NOT EXISTS session_members (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id   TEXT,
                player_uid   TEXT,
                nickname     TEXT,
                is_owner     INTEGER DEFAULT 0,
                team         INTEGER DEFAULT 1,
                slot         INTEGER DEFAULT 1,
                platform     TEXT DEFAULT 'mobile',
                joined_at    TEXT,
                updated_at   TEXT,
                last_event   TEXT,
                UNIQUE(session_id, player_uid)
            );

            CREATE TABLE IF NOT EXISTS users (
                token        TEXT PRIMARY KEY,
                user_id      TEXT,
                plan_type    TEXT DEFAULT 'credit',
                credit       REAL DEFAULT 0.0,
                total_spent  REAL DEFAULT 0.0,
                created_at   TEXT,
                enabled      INTEGER DEFAULT 1
            );
        """)


# ─── Session CRUD ─────────────────────────────────────────────────────────────

def create_session(
    room_id: int,
    room_name: str,
    password: str,
    account_uid: str,
    account_jwt: str,
    region: str,
    config_type: str,
    invite_code: str,
    invite_link: str,
    invite_codes: list,
    delay_minutes: int,
    user_token: str,
) -> dict:
    session_id = uuid.uuid4().hex
    now = _now()
    exp = _expires_at(delay_minutes)
    with _conn() as con:
        con.execute(
            """INSERT INTO sessions VALUES (
                :sid, :room_id, :room_name, :password,
                :uid, :jwt, :region, 'active',
                :cfg, :invite_code, :invite_link, :codes,
                :created_at, :expires_at, NULL, NULL, :user_token
            )""",
            {
                "sid": session_id,
                "room_id": room_id,
                "room_name": room_name,
                "password": password,
                "uid": account_uid,
                "jwt": account_jwt,
                "region": region,
                "cfg": config_type,
                "invite_code": invite_code,
                "invite_link": invite_link,
                "codes": json.dumps(invite_codes),
                "created_at": now,
                "expires_at": exp,
                "user_token": user_token,
            },
        )
    return get_session(session_id)


def get_session(session_id: str) -> dict | None:
    with _conn() as con:
        row = con.execute(
            "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
        ).fetchone()
    if not row:
        return None
    d = dict(row)
    d["invite_code_candidates"] = json.loads(d.pop("invite_codes", "[]") or "[]")
    return d


def list_sessions(user_token: str) -> list[dict]:
    with _conn() as con:
        rows = con.execute(
            "SELECT * FROM sessions WHERE user_token = ? ORDER BY created_at DESC",
            (user_token,),
        ).fetchall()
    result = []
    for row in rows:
        d = dict(row)
        d["invite_code_candidates"] = json.loads(d.pop("invite_codes", "[]") or "[]")
        result.append(d)
    return result


def update_status(session_id: str, status: str):
    now = _now()
    extra = {}
    if status == "started":
        extra["started_at"] = now
    elif status == "released":
        extra["released_at"] = now

    with _conn() as con:
        if status == "started":
            con.execute(
                "UPDATE sessions SET status=?, started_at=?, expires_at=? WHERE session_id=?",
                (status, now, _expires_at(3), session_id),
            )
        elif status == "released":
            con.execute(
                "UPDATE sessions SET status=?, released_at=? WHERE session_id=?",
                (status, now, session_id),
            )
        else:
            con.execute(
                "UPDATE sessions SET status=? WHERE session_id=?",
                (status, session_id),
            )


def delete_session(session_id: str):
    with _conn() as con:
        con.execute("DELETE FROM session_members WHERE session_id=?", (session_id,))
        con.execute("DELETE FROM sessions WHERE session_id=?", (session_id,))


def purge_expired():
    """Remove sessões expiradas."""
    now = _now()
    with _conn() as con:
        rows = con.execute(
            "SELECT session_id FROM sessions WHERE expires_at < ? AND status NOT IN ('released')",
            (now,),
        ).fetchall()
        for row in rows:
            sid = row["session_id"]
            con.execute("DELETE FROM session_members WHERE session_id=?", (sid,))
            con.execute("DELETE FROM sessions WHERE session_id=?", (sid,))


# ─── Members ──────────────────────────────────────────────────────────────────

def upsert_member(session_id: str, member: dict):
    now = _now()
    with _conn() as con:
        con.execute(
            """INSERT INTO session_members
               (session_id, player_uid, nickname, is_owner, team, slot,
                platform, joined_at, updated_at, last_event)
               VALUES (?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(session_id, player_uid) DO UPDATE SET
                 nickname=excluded.nickname, team=excluded.team,
                 slot=excluded.slot, updated_at=excluded.updated_at,
                 last_event=excluded.last_event""",
            (
                session_id,
                member["player_uid"],
                member.get("nickname", ""),
                int(member.get("is_owner", False)),
                member.get("team", 1),
                member.get("slot", 1),
                member.get("platform", "mobile"),
                member.get("joined_at") or now,
                now,
                member.get("last_event", ""),
            ),
        )


def get_members(session_id: str) -> list[dict]:
    with _conn() as con:
        rows = con.execute(
            "SELECT * FROM session_members WHERE session_id=? AND is_owner=0",
            (session_id,),
        ).fetchall()
    return [dict(r) for r in rows]


# ─── Users / Auth ─────────────────────────────────────────────────────────────

def get_user(token: str) -> dict | None:
    with _conn() as con:
        row = con.execute(
            "SELECT * FROM users WHERE token=?", (token,)
        ).fetchone()
    return dict(row) if row else None


def create_user(token: str, credit: float = 10.0) -> dict:
    user_id = uuid.uuid4().hex[:12]
    now = _now()
    with _conn() as con:
        con.execute(
            "INSERT OR IGNORE INTO users VALUES (?,?,?,?,?,?,?)",
            (token, user_id, "credit", credit, 0.0, now, 1),
        )
    return get_user(token)


def deduct_credit(token: str, amount: float):
    with _conn() as con:
        con.execute(
            "UPDATE users SET credit=credit-?, total_spent=total_spent+? WHERE token=?",
            (amount, amount, token),
        )
