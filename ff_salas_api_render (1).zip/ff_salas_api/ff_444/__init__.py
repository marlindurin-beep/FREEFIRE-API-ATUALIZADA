import requests
import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

class FFCore:
    def __init__(self):
        self._k = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
        self._i = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])
        

        self._api = base64.b64decode("aHR0cHM6Ly9iZHZlcnNpb24uZ2dibHVlZm94LmNvbS9saXZlL3Zlci5waHA/dmVyc2lvbj0xLjEyMC4yJmxhbmc9YXImZGV2aWNlPWFuZHJvaWQmY2hhbm5lbD1hbmRyb2lkJmFwcHN0b3JlPWdvb2dsZXBsYXkmcmVnaW9uPU1FJndoaXRlbGlzdF92ZXJzaW9uPTEuMy4wJndoaXRlbGlzdF9zcF92ZXJzaW9uPTEuMC4wJmRldmljZV9uYW1lPWdvb2dsZSUyMEcwMTFBJmRldmljZV9DUFU9QVJNdjclMjBWRlB2MyUyME5FT04lMjBWTUgmZGV2aWNlX0dQVT1BZHJlbm8lMjAoVE0pJTIwNjQwJmRldmljZV9tZW09MTk5Mw==").decode('utf-8')

    def get_server_info(self):
        try:
            r = requests.get(self._api).json()
            server_url = r['server_url']
            ob_version = r['latest_release_version']
            
            clean_domain = server_url.replace('https://', '').replace('http://', '').split('/')[0]
            clean_domain = clean_domain.replace('loginbp.', '').replace('clientbp.', '')
            
            client_base = f"https://clientbp.{clean_domain}"
            login_base = f"https://loginbp.{clean_domain}"
            return client_base, login_base, ob_version
        except Exception:
            return "https://clientbp.ggblueshark.com", "https://loginbp.ggblueshark.com", "OB52"

    def encrypt(self, data_bytes):
        cipher = AES.new(self._k, AES.MODE_CBC, self._i)
        return cipher.encrypt(pad(data_bytes, AES.block_size))

    def decrypt(self, encrypted_bytes):
        cipher = AES.new(self._k, AES.MODE_CBC, self._i)
        decrypted = cipher.decrypt(encrypted_bytes)
        try:
            return unpad(decrypted, AES.block_size)
        except:
            return decrypted